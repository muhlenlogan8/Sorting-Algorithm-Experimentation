#include <iostream>
using namespace std;

int partition(int arr[], int start, int end);
void quickSort(int arr[], int start, int end);