#include <iostream>
#include <iomanip>
using namespace std;

void PrintTable(int arrBS[], int arrIS[], int arrMS[], int arrQS[], int arrRS[]);